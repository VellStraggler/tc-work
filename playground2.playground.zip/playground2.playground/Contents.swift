import UIKit
// Swift Assignment 2

//1.functions and its types
func classicFunction() -> Bool? {
    print("Do something classic")
    return true
}
func argumentativeFunction(doSomething: Bool) {
    if doSomething {
        print("Do something")
    } else {
        print("Be a slacker")
    }
}
func highLevelFunction(action: (() -> ())?) {
    action?()
}
//2.closures and its types
let classicClosure = {
    print("Sane people call this a lambda")
}
highLevelFunction { classicClosure() }
highLevelFunction(action:nil)
func doLater(_ action: @escaping @Sendable () -> ()) {
    DispatchQueue.main.async {
        action()
    }
}
let argedClosure: (Int)->() = { (a: Int) in
    print(String(a))
}

//3.Tuples
var tupleA = (1, 3 ,4)
tupleA.1 = 4
print(tupleA)
func tupleGiver() -> (Int, Int) {
    return (1,2)
}

let b = 3
//4.Conditional Statements
if("I explain this poorly".contains("Explain")) {
    print("success")
} else if 1+b==4 {
    print("F--")
} else {
    print("Z+!")
}
//5.Classes
class DontCare {
    var anInt: Int
    
    init(anInt: Int) {
        self.anInt = anInt
    }
    func why() {
        print("Don't know.")
    }
}
class ReallyDontCare: DontCare {
    
    override func why() {
        print("Really don't know.")
    }
}
let rdc: ReallyDontCare = ReallyDontCare(anInt: 1)
rdc.why()

//6.Structs
struct DontCareStruct {
    var anInt: Int

    mutating func increment() {
        anInt += 1
    }
}
var a = DontCareStruct(anInt: 3)
print(a.anInt)
var c = a
c.increment()
print("New integer in C: \(c.anInt)")
print("integer in A: \(a.anInt)")
