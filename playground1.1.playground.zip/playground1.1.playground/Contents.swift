import UIKit

// 1.Constant with 4.Explicit inference
// 6.Different collections- Array, set, dictionary usages
let tileSize: [Character:Int] = ["x": 8, "y": 4]

// 2.Variable with 4.Explicit inference
// 6.Different collections- Array, set, dictionary usages
var playerSprite: [[Character]] = Array(repeating:Array(
    repeating: "i", count: tileSize["x"]!
    ), count: tileSize["y"]!)


// 2.Constant with 3.Type inferencing
let mysteryLine =
    " __  _  /# \\[๏'-\\--'/¯¯¯//¯\\\\   "
// 2.Variable with 4.Explicit inference
// 5.What all data types we have in swift print those
// 6.Differnt collections- Array, set, dictionary usages
var dataTypes: Set<String> =
    ["Int", "UInt", "Double", "Float", "Bool", "String", "Character", "Array", "Dictionary", "Set", "Optional", "Tuple", "Any", "Void", "Never"]
var dtTexture: String = dataTypes.joined(separator: ",")

// 7.Differnt Loops (for loop , while loop, repeat while,stride) usage for Array, set, dictionary
var i = 0
for y in 0..<tileSize["y"]! {
    for x in 0..<tileSize["x"]! {
        let index = mysteryLine.index(mysteryLine.startIndex, offsetBy:i)
        playerSprite[y][x] = mysteryLine[index]
        i+=1
    }
}

var minimap = [
    [1,0,1,0,0],
    [0,0,1,1,1],
    [1,0,0,0,0],
    [1,0,2,0,1],
    [1,1,1,1,1]
]
var printMap = Array(repeating: Array(
    repeating: Character(" "), count: minimap[0].count * tileSize["x"]!
    ), count: minimap.count * tileSize["y"]!)

i = 0
var fX = 0
var fY = 0
var textureI = dtTexture.startIndex
var r = 0
// 7.Different Loops (for loop , while loop, repeat while,stride) usage for Array, set, dictionary
repeat {
    for mY in 0..<minimap.count {
        for mX in 0..<minimap[0].count {
            
            switch(minimap[mY][mX]) {
            case 1: // word wall
                for bY in 0..<tileSize["y"]! {
                    for bX in 1..<tileSize["x"]! {
                        fX = (mX * tileSize["x"]!) + bX
                        fY = (mY * tileSize["y"]!) + bY
                        
                        textureI = dtTexture.index(dtTexture.startIndex, offsetBy: i)
                        printMap[fY][fX] = dtTexture[textureI]
                        
                        i = (i+1)%dtTexture.count
                    }
                }
            case 2: // mystery tile
                for bY in 0..<tileSize["y"]! {
                    for bX in 0..<tileSize["x"]! {
                        fX = (mX * tileSize["x"]!) + bX
                        fY = (mY * tileSize["y"]!) + bY
                        
                        printMap[fY][fX] = playerSprite[bY][bX]
                    }
                }
            default: // open space
                continue
            }
        }
    }
    var printLine = String(repeating:"\n", count:10)
    for y in 0..<printMap.count {
        for x in 0..<printMap[0].count {
            printLine += String(printMap[y][x])
        }
        printLine += "\n"
    }
    print(printLine, terminator:"")
    r+=1
} while (r < 1000)
